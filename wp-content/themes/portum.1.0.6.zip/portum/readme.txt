# Portum
Tags: one-column, two-columns, left-sidebar, right-sidebar, translation-ready

Requires at least:	4.0
Tested up to:		5.0

## Description

Portum

### License

Portum WordPress theme, Copyright (C) 2018 https://www.machothemes.com/
Portum WordPress theme is licensed under the GPL3.

Unless otherwise specified, all the theme files, scripts and images are licensed under GNU General Public License. The exceptions to this license are as follows:

#### Vendors
Slick
	-- Copyright Ken Wheeler
	-- Licensed under the MIT license. (https://github.com/kenwheeler/slick/blob/master/LICENSE)

Font Awesome
	-- Copyright Font Awesome by Dave Gandy - http://fontawesome.io
	-- License: MIT License (http://opensource.org/licenses/mit-license.html)

Selectize
	-- Copyright (c) 2013 Brian Reavis & contributors
	-- Licensed under the Apache License, Version 2.0 (the "License");

Epsilon
	-- Macho Themes https://www.machothemes.com/
	-- available for use under the MIT License

SuperFish
	-- Copyright (c) 2013 Joel Birch.
	-- available for use under the MIT License http://users.tpg.com.au/j_birch/plugins/superfish/

Hover Intent
	-- Copyright (c) 2007 - 2014 Brian Cherne.
	-- available for use under the MIT License  http://cherne.net/brian/resources/jquery.hoverIntent.html

#### Fonts

Google Fonts

	-- License: SIL OFL 1.1
	-- URL: http://scripts.sil.org/OFL

#### Images

Screenshot: https://pixabay.com/en/antelope-canyon-sandstone-canyon-1128815/
00_header_01.jpg: https://pixabay.com/en/tea-time-poetry-coffee-reading-3240766/