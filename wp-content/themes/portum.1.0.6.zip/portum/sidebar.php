<?php
/**
 * The sidebar containing the main widget area.
 *
 * @package Portum
 */

if ( is_active_sidebar( 'sidebar' ) ) {
	dynamic_sidebar( 'sidebar' );
}
